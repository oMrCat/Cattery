﻿#include "Traversal_process.h"
#include <stdio.h>
#include <stdlib.h>

//枚举当前进程，打印 PID 与进程名，由用户输入 PID 选择要附加的进程
DWORD Traversal_process::SelectProcess()
{
	HANDLE hProcessSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hProcessSnapshot == INVALID_HANDLE_VALUE)
	{
		printf("进程枚举失败（错误码 %lu）\n", GetLastError());
		return 0;
	}
	PROCESSENTRY32 pe = { 0 };
	pe.dwSize = sizeof(PROCESSENTRY32);
	printf("可附加进程（PID  进程名）：\n");
	int shown = 0;
	if (Process32First(hProcessSnapshot, &pe))
	{
		do
		{
			if (pe.th32ProcessID != 0)
			{
				printf("  %5lu  %ls\n", pe.th32ProcessID, pe.szExeFile);
				++shown;
			}
		} while (shown < 60 && Process32Next(hProcessSnapshot, &pe));
	}
	CloseHandle(hProcessSnapshot);
#ifdef _WIN64
	printf("注意：本程序为 x64，只能附加 64 位进程（32 位进程请使用 Win32 版本）。\n");
#else
	printf("注意：本程序为 Win32，只能附加 32 位进程（64 位进程请使用 x64 版本）。\n");
#endif

	char text[32] = { 0 };
	printf("请输入要附加的 PID：");
	if (scanf_s("%31s", text, (UINT)sizeof(text)) != 1)
		return 0;
	char* end = nullptr;
	DWORD pid = (DWORD)strtoul(text, &end, 10);
	if (end == text || *end != '\0' || pid == 0)
	{
		printf("PID 格式错误：%s\n", text);
		return 0;
	}
	return pid;
}
