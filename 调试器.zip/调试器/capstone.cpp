#include "capstone.h"
csh Capstone::Handle = { 0 };
cs_opt_mem Capstone::OptMem = { 0 };

//��ʼ�����������
void Capstone::Init()
{
	//���öѿռ�Ļص�����
	OptMem.free = free;
	OptMem.calloc = calloc;
	OptMem.malloc = malloc;
	OptMem.realloc = realloc;
	OptMem.vsnprintf = (cs_vsnprintf_t)vsprintf_s;

	//ע��ѿռ�����麯��
	cs_option(NULL, CS_OPT_MEM, (size_t)&OptMem);
	// ��һ�����
#ifdef _WIN64
	cs_open(CS_ARCH_X86, CS_MODE_64, &Capstone::Handle);
#else
	cs_open(CS_ARCH_X86, CS_MODE_32, &Capstone::Handle);
#endif
}
// �����ָ�����������
void Capstone::DisAsm(HANDLE Handle, LPVOID Addr, DWORD Count)
{
	// ������ȡָ��λ���ڴ�Ļ�������Ϣ
	cs_insn* ins = nullptr;
	PCHAR buff = new CHAR[Count * 16]{ 0 };

	// ��ȡָ�����ȵ��ڴ�ռ�

	//call  rep
	SIZE_T dwWrite = 0;
	ReadProcessMemory(Handle, (LPVOID)Addr, buff, Count * 16, &dwWrite);
	size_t count = cs_disasm(Capstone::Handle, (uint8_t*)buff, Count * 16, (uint64_t)Addr, 0, &ins);
	for (DWORD i = 0; i < Count; ++i)
	{
		printf("%08X\t", (UINT)ins[i].address);
		for (uint16_t j = 0; j < 16; ++j)
		{
			if (j < ins[i].size)
				printf("%02X", ins[i].bytes[j]);
			else
				printf("  ");
		}
		// �����Ӧ�ķ����
		printf("\t%s %s\n", ins[i].mnemonic, ins[i].op_str);
	}

	printf("\n");
	// �ͷŶ�̬����Ŀռ�
	delete[] buff;
	cs_free(ins, count);
}

void Capstone::nRegister(HANDLE hThread)
{
	CONTEXT ct = { 0 };
	ct.ContextFlags = CONTEXT_ALL;
	GetThreadContext(hThread, &ct);
#ifdef _WIN64
	printf("RAX:%016I64X\n", ct.Rax);
	printf("RBX:%016I64X\n", ct.Rbx);
	printf("RCX:%016I64X\n", ct.Rcx);
	printf("RDX:%016I64X\n", ct.Rdx);
	printf("RDI:%016I64X\n", ct.Rdi);
	printf("RSI:%016I64X\n", ct.Rsi);
	printf("RSP:%016I64X\n", ct.Rsp);
	printf("RBP:%016I64X\n", ct.Rbp);
	printf("RIP:%016I64X\n", ct.Rip);
	printf("EFlags:%08X\n", ct.EFlags);
#else
	printf("EAX:%08X\n", ct.Eax);
	printf("EBX:%08X\n", ct.Ebx);
	printf("ECX:%08X\n", ct.Ecx);
	printf("EDX:%08X\n", ct.Edx);
	printf("EDI:%08X\n", ct.Edi);
	printf("ESI:%08X\n", ct.Esi);
	printf("ESP:%08X\n", ct.Esp);
	printf("EBP:%08X\n", ct.Ebp);
	printf("EIP:%08X\n", ct.Eip);
	printf("EFlags:%08X\n", ct.EFlags);
#endif
}

void Capstone::Stack(HANDLE hProcess, HANDLE hThread, DWORD Count)
{
	CONTEXT ct = { 0 };
	ct.ContextFlags = CONTEXT_ALL;
	GetThreadContext(hThread, &ct);
	BYTE buff[512];
	SIZE_T dwRead = 0;
#ifdef _WIN64
	ReadProcessMemory(hProcess, (LPCVOID)ct.Rsp, buff, 512, &dwRead);
	for (DWORD i = 0; i < Count; i++)
	{
		// x64: each stack slot is 8 bytes (pointer width)
		printf("%016I64X\n", ((ULONG_PTR*)buff)[i]);
	}
#else
	ReadProcessMemory(hProcess, (LPCVOID)ct.Esp, buff, 512, &dwRead);
	for (DWORD i = 0; i < Count; i++)
	{
		printf("%08x\n", ((DWORD*)buff)[i]);
	}
#endif
}

void Capstone::nMemory(HANDLE hProcess, LPCVOID addr, DWORD Count)
{
	BYTE buff[512];
	SIZE_T dwRead = 0;
	ReadProcessMemory(hProcess, addr, buff, 512, &dwRead);
	if (Count < 16)
	{
		printf("%p:", (PVOID)addr);
		for (DWORD i = 0; i < Count; i++)
		{
			printf("%02x ", buff[i]);
		}
	}
	else
	{
		DWORD i = 0;
		int n = 0;
		if (Count % 16 == 0)
		{

			n = Count / 16;
		}
		else if (Count % 16 != 0)
		{
			n = Count / 16 + 1;
		}
		for (int j = 0; j < n; j++)
		{
			printf("%p:", (PVOID)((ULONG_PTR)addr + (16 * (size_t)j)));
			for (; i < Count; i++)
			{
				if (i % (16 * (j + 1)) == 0 && i != 0)
				{
					printf("\n");
					break;
				}
				printf("%02x ", buff[i]);
			}
		}
	}
	printf("\n\t");

}

void Capstone::GetModules(DWORD PID)
{
	setlocale(LC_ALL, "chs");

	//����һЩ����
	HANDLE hProcessSnapshot = 0;
	MODULEENTRY32 me = {};
	me.dwSize = sizeof(MODULEENTRY32);
	//����ģ�����
	hProcessSnapshot = CreateToolhelp32Snapshot(
		TH32CS_SNAPMODULE,//��������ģ�����
		PID              //����ID��ֻ���ڴ���ģ�飬�ѿ��յ�ʱ��ָ������
	);
	if (hProcessSnapshot == INVALID_HANDLE_VALUE)
	{
		return ;
	}
	//��ȡ��һ�����̵���Ϣ�������ȡ�ɹ����Ϳ��Լ��������ȡ
	BOOL bSuccess = Module32First(
		hProcessSnapshot,//���յľ��
		&me              //��һ�����̵���Ϣ
	);
	//ѭ�����������еĽ�����Ϣ
	if (bSuccess == TRUE)
	{
		do {
			printf("%S:%S\n", me.szModule, me.szExePath);
		} while (Module32Next(hProcessSnapshot, &me));
	}
	CloseHandle(hProcessSnapshot);
}


void Capstone::AlternRegister(HANDLE hThread, const char* Reg, DWORD dwValue)
{
	CONTEXT ct = { 0 };
	ct.ContextFlags = CONTEXT_ALL;
	GetThreadContext(hThread, &ct);
#ifdef _WIN64
	// x64: a 32-bit register name maps to the low 32 bits of its 64-bit register.
	// Replace only the low 32 bits and keep the high 32 bits so semantics stay identical.
	ULONG_PTR* reg = nullptr;
	if (strcmp(Reg, "EAX") == 0) reg = &ct.Rax;
	else if (strcmp(Reg, "EBX") == 0) reg = &ct.Rbx;
	else if (strcmp(Reg, "ECX") == 0) reg = &ct.Rcx;
	else if (strcmp(Reg, "EDX") == 0) reg = &ct.Rdx;
	else if (strcmp(Reg, "EDI") == 0) reg = &ct.Rdi;
	else if (strcmp(Reg, "ESI") == 0) reg = &ct.Rsi;
	else if (strcmp(Reg, "EIP") == 0) reg = &ct.Rip;
	if (reg != nullptr)
	{
		*reg = (*reg & ~(ULONG_PTR)0xFFFFFFFF) | (ULONG_PTR)dwValue;
	}
#else
	if (strcmp(Reg, "EAX") == 0)
	{
		ct.Eax = dwValue;
	}
	else if (strcmp(Reg, "EBX") == 0)
	{
		ct.Ebx = dwValue;
	}
	else if (strcmp(Reg, "ECX") == 0)
	{
		ct.Ecx = dwValue;
	}
	else if (strcmp(Reg, "EDX") == 0)
	{
		ct.Edx = dwValue;
	}
	else if (strcmp(Reg, "EDI") == 0)
	{
		ct.Edi = dwValue;
	}
	else if (strcmp(Reg, "ESI") == 0)
	{
		ct.Esi = dwValue;
	}
	else if (strcmp(Reg, "EIP") == 0)
	{
		ct.Eip = dwValue;
	}
#endif

	SetThreadContext(hThread, &ct);
}

void Capstone::AlternMemory(HANDLE hProcess, LPVOID addr, const BYTE* buff, int Count)
{
	SIZE_T dwRead = 0;
	WriteProcessMemory(hProcess, addr, buff, Count, &dwRead);
}

void Capstone::AlterDisAsm(HANDLE hProcess)
{
	// ����һ���������ڲ����������.
	XEDPARSE xed = { 0 };
	printf("��������ָ��:\n");
	// ��������opcode�ĵĳ�ʼ��ַ
	scanf_s("%I64x", &xed.cip);
	// ����ָ��
	// ʹ��  gets_s()  ���������������룬�����ո���ַ�
	gets_s(xed.instr, XEDPARSE_MAXBUFSIZE);
	SIZE_T dwWrite = 0;
	// ʹ�� XEDParseAssemnle() ���������ָ��ת���� OPCODE
	if (XEDPARSE_OK != XEDParseAssemble(&xed))
	{
		printf("ָ�����%s\n", xed.error);
	}
	else
	{
		WriteProcessMemory(hProcess, (LPVOID)xed.cip, xed.dest, xed.dest_size, &dwWrite);
		for (DWORD i = 0; i < (DWORD)xed.dest_size; i++)
		{
			printf("%x ", xed.dest[i]);
		}
	}
	return;
}

void Capstone::SetStepFlag(HANDLE hProcess,HANDLE hThread)
{
	CONTEXT ct = { 0 };
	ct.ContextFlags = CONTEXT_ALL;
	GetThreadContext(hThread, &ct);
#ifdef _WIN64
	ULONG_PTR Address = ct.Rip;
#else
	ULONG_PTR Address = ct.Eip;
#endif
	cs_insn* ins = nullptr;
	CHAR buff[512] = { 0 };
	SIZE_T bytesRead = 0;
	ReadProcessMemory(hProcess, (LPVOID)Address, buff, 512, &bytesRead);//������ReadProcessMemory����������
	cs_disasm(Capstone::Handle, (uint8_t*)buff, (size_t)bytesRead, (uint64_t)Address, 0, &ins);
	//DWORD PID = GetProcessId(hProcess);
	if (!memcmp(ins->mnemonic, "call", 4) || !memcmp(ins->mnemonic, "rep", 3))
	{
		Breakpoint::SetInt3BreakPoint(hProcess, (LPVOID)(Address + ins->size));
	}
	else
	{
		Breakpoint::SetTfBreakPoint(hThread);
	}
}


int Capstone::GetInstrLen(HANDLE Handle, LPVOID Addr, DWORD Count, char* Code)
{
	// ������ȡָ��λ���ڴ�Ļ�������Ϣ
	cs_insn* ins = nullptr;
	PCHAR buff = new CHAR[Count * 16]{ 0 };
	int len = 0;
	// ��ȡָ�����ȵ��ڴ�ռ�
	SIZE_T dwWrite = 0;
	ReadProcessMemory(Handle, (LPVOID)Addr, buff, Count * 16, &dwWrite);
	size_t count = cs_disasm(Capstone::Handle, (uint8_t*)buff, Count * 16, (uint64_t)Addr, 0, &ins);

	//for (DWORD i = 0; i < Count; ++i)
	//{
	//	printf("-----%08X\t", (UINT)ins[i].address); 
	//	for (uint16_t j = 0; j < 16; ++j)
	//	{
	//		if (j < ins[i].size)
	//			printf("%02X", ins[i].bytes[j]);
	//		else
	//			printf("  ");
	//	}
	//	// �����Ӧ�ķ����
	//	printf("\t%s %s\n", ins[i].mnemonic, ins[i].op_str);
	//}
	strcpy_s(Code, 10, ins[0].mnemonic);
	len = ins[0].size;
	//printf("\n");
	// �ͷŶ�̬����Ŀռ�
	delete[] buff;
	cs_free(ins, count);
	return len;
}
