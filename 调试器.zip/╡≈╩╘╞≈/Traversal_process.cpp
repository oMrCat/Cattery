#include "Traversal_process.h"
#define nFile  L"111.exe"
DWORD Traversal_process::nProcess()
{
	//WCHAR* ProcessName = L"111.exe";
	HANDLE hProcessSnapshot = 0;
	PROCESSENTRY32 pe = { 0 };
	pe.dwSize = sizeof(PROCESSENTRY32);
	hProcessSnapshot = CreateToolhelp32Snapshot(
		TH32CS_SNAPPROCESS,
		0
	);
	if (hProcessSnapshot == INVALID_HANDLE_VALUE)
	{
		return 0;
	}
	BOOL bSucess = Process32First(
		hProcessSnapshot,
		&pe
	);
	if (bSucess == true)
	{

		do
		{
			if (!wcscmp(pe.szExeFile, nFile))
			{

				return pe.th32ProcessID;
			}
		} while (Process32Next(hProcessSnapshot, &pe));
	}
	return 0;
}
