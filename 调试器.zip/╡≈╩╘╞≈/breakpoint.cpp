#include "breakpoint.h"
#include<vector>
using std::vector;
vector<bp>g_bp;
vector<bp>d_bp;
PreviousbpInfo bpInfo;
extern LPVOID oep;
//ģ��DR7�Ľṹ��
typedef struct _DBG_REG7 {
	unsigned L0 : 1; unsigned G0 : 1;
	unsigned L1 : 1; unsigned G1 : 1;
	unsigned L2 : 1; unsigned G2 : 1;
	unsigned L3 : 1; unsigned G3 : 1;
	unsigned LE : 1; unsigned GE : 1;
	unsigned : 6;// ��������Ч�ռ�
	unsigned RW0 : 2; unsigned LEN0 : 2;
	unsigned RW1 : 2; unsigned LEN1 : 2;
	unsigned RW2 : 2; unsigned LEN2 : 2;
	unsigned RW3 : 2; unsigned LEN3 : 2;
} R7, * PR7;
void Breakpoint::SetTfBreakPoint(HANDLE hThread)
{
	//TF �����־���˱�־Ϊ1ʱ��CPUÿ�ν���ִ��1��ָ�ִ����֮���־λ��Ϊ0
   //��ȡ���еļĴ�������Ϣ
	CONTEXT context{ CONTEXT_FULL };
	//�ѵ�ǰ�߳���������õļĴ�����Ϣ��䵽���context����
	GetThreadContext(hThread, &context);
	context.EFlags = 0x00000100;
	//�������־��ԭ
	SetThreadContext(hThread, &context);
}

void Breakpoint::SetInt3BreakPoint(HANDLE hProcess, LPVOID addr)
{
	//	����cc������Ҫ�޸�
	bp int3Bp = { 0 };
	//��ǰ�¶ϵĵ�ַ�ŵ�int3Bp����
	int3Bp.addr = addr;
	DWORD dwRead = 0;
	//��ȡ�ڴ�,��ͷһ���ֽڱ�������
	ReadProcessMemory(hProcess, addr, &int3Bp.oldBytes, 1, &dwRead);
	//д��cc
	BYTE cc = '\xcc';
	WriteProcessMemory(hProcess, addr, &cc, 1, &dwRead);
	//���ϵ����vector��
	g_bp.push_back(int3Bp);
	d_bp.push_back(int3Bp);
}

void Breakpoint::FixInt3BreakPoint(HANDLE hProcess, LPVOID addr, HANDLE hThread)
{
	for (size_t i = 0; i < g_bp.size(); i++)
	{
		if (addr == g_bp[i].addr)
		{
			bpInfo.previousAddr = addr;
			DWORD bytes = 0;
			WriteProcessMemory(hProcess, addr, &g_bp[i].oldBytes, 1, &bytes);
			//ʹ���̵߳�������
			CONTEXT context{ CONTEXT_ALL };
			//��ȡ�Ĵ���
			GetThreadContext(hThread, &context);
			context.Eip -= 1;
			//д��Ĵ���
			SetThreadContext(hThread, &context);
			//oep�����������öϵ㣬�޸�TF�ϵ㣬�Ͳ��ᴥ��
			if (::oep != addr)
			{
				Breakpoint::SetTfBreakPoint(hThread);
				bpInfo.PreviousIsBp = 1;
				bpInfo.whichbp = 0;
			}
			//�������뵽��һ��
			Breakpoint::SetTfBreakPoint(hThread);
			bpInfo.PreviousIsBp = 1;
			//����int3�ϵ�
			bpInfo.whichbp = 0;
			//ɾ��g_bp[i].addr�ĵ�ַ
			vector<bp>::iterator it = g_bp.begin() + i;
			g_bp.erase(it);
		}
	}
}

void Breakpoint::SetHwBreakPoint(HANDLE hThread, LPVOID addr, int type, int len)
{
	CONTEXT context{ CONTEXT_ALL };
	GetThreadContext(hThread, &context);
	PR7 Dr7 = (PR7)&context.Dr7;

	if (Dr7->L0 == 0)
	{
		Dr7->L0 = 1;
		Dr7->LEN0 = len;
		Dr7->RW0 = type;
		context.Dr0 = (DWORD)addr;
	}
	else if (Dr7->L1 == 0)
	{
		Dr7->L1 = 1;
		Dr7->LEN1 = len;
		Dr7->RW1 = type;
		context.Dr1 = (DWORD)addr;
	}
	else if (Dr7->L2 == 0)
	{
		Dr7->L2 = 1;
		Dr7->LEN2 = len;
		Dr7->RW2 = type;
		context.Dr2 = (DWORD)addr;
	}
	else if (Dr7->L3 == 0)
	{
		Dr7->L3 = 1;
		Dr7->LEN3 = len;
		Dr7->RW3 = type;
		context.Dr3 = (DWORD)addr;
	}
	else
	{
		printf("û�п��õ�Ӳ���Ĵ�����!");
	}
	SetThreadContext(hThread, &context);
	bpInfo.previousAddr = (LPVOID)addr;
}

void Breakpoint::FixHwBreakpoint(HANDLE hThread, HANDLE hProcess, LPVOID addr)
{
	CONTEXT context{ CONTEXT_ALL };
	GetThreadContext(hThread, &context);
	PR7 Dr7 = (PR7)&context.Dr7;
	LPVOID addr2 = 0;
	switch (context.Dr6 & 0xF)
	{
	case 1:
	{
		Dr7->L0 = 0;
		bpInfo.type = Dr7->RW0;
		addr2 = (LPVOID)context.Dr0;
		bpInfo.len = Dr7->LEN0;
	} break;
	case 2:
	{
		Dr7->L1 = 0;
		bpInfo.type = Dr7->RW1;
		addr2 = (LPVOID)context.Dr1;
		bpInfo.len = Dr7->LEN1;
	} break;
	case 4:
	{

		Dr7->L2 = 0;
		bpInfo.type = Dr7->RW2;
		addr2 = (LPVOID)context.Dr2;
		bpInfo.len = Dr7->LEN2;
	}
	break;
	case 8:
	{
		Dr7->L3 = 0;
		bpInfo.type = Dr7->RW3;
		addr2 = (LPVOID)context.Dr3;
		bpInfo.len = Dr7->LEN3;
	}
	break;
	default:
		break;
	}
	bpInfo.PreviousIsBp = 1;
	bpInfo.whichbp = 1;
	if (bpInfo.type == 0)
	{
		bpInfo.previousAddr == addr;
	}
	else if (bpInfo.type == 1 || bpInfo.type == 3)
	{

		bpInfo.previousAddr = addr2;
	}
	SetThreadContext(hThread, &context);
	Breakpoint::SetTfBreakPoint(hThread);
}

DWORD dwOldProtected;
LPVOID addr;
int type;
extern LPVOID g_dWMemAddr;
extern int nIsGo;
void Breakpoint::SetMmBreakpoint(HANDLE hProcess, LPVOID addr, int type)
{
	if (type == 8)
	{
		Breakpoint::SetInt3BreakPoint(hProcess, (LPVOID)addr);
	}
	else if (type == 1)
	{
		::addr = addr;
		::type = type;
		VirtualProtectEx(hProcess, addr, 1, PAGE_EXECUTE_READ, &dwOldProtected);
	}
	else if (type == 0)
	{
		::addr = addr;
		::type = type;
		VirtualProtectEx(hProcess, addr, 1, PAGE_NOACCESS, &dwOldProtected);
	}
}

void Breakpoint::FixMmBreakpoint(HANDLE hProcess, HANDLE hThread, LPVOID addr, int type)
{
	if (type == 8)
	{
		if (g_dWMemAddr == addr)
		{
			nIsGo = 1;
		}
		VirtualProtectEx(hProcess, addr, 1, dwOldProtected, &dwOldProtected);
	}
	if (type == 0)
	{
		if (g_dWMemAddr == addr)
		{
			nIsGo = 1;
		}
		VirtualProtectEx(hProcess, addr, 1, dwOldProtected, &dwOldProtected);
	}
	if (type == 1)
	{
		if (g_dWMemAddr == addr)
		{
			nIsGo = 1;
		}
		VirtualProtectEx(hProcess, addr, 1, dwOldProtected, &dwOldProtected);
	}
	SetTfBreakPoint(hThread);
	bpInfo.PreviousIsBp = 1;
	bpInfo.whichbp = 2;
}

void Breakpoint::Deletepoint(HANDLE hProcess, LPVOID addr, HANDLE hThread)
{
	for (size_t i = 0; i < d_bp.size(); i++)
	{
		if (addr == d_bp[i].addr)
		{
			bpInfo.previousAddr = addr;
			bpInfo.PreviousIsBp = 0;
			DWORD bytes = 0;
			WriteProcessMemory(hProcess, addr, &d_bp[i].oldBytes, 1, &bytes);
			vector<bp>::iterator it = d_bp.begin() + i;
			d_bp.erase(it);
		}
	}
}


