#pragma once
#include<windows.h>
#include<TlHelp32.h>

class Traversal_process
{
public:
	DWORD nProcess();
};