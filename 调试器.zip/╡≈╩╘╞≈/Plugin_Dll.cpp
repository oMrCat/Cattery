#include "Plugin_Dll.h"
vector<CString>FileName;

void Plugin_Dll::EnumFile()
{
	//vector<CString>& filenames
	CString fn;
	WIN32_FIND_DATA  wfd = {};
	setlocale(LC_ALL, "CHS"); // �����ַ������ʽ
	//�ҵ���һ���ļ�
	TCHAR szDirtoryPath[MAX_PATH] = { 0 };
	_stprintf_s(szDirtoryPath, _T("%s\\%s"), PATH, _T("*"));
	HANDLE hFindFile = FindFirstFile(szDirtoryPath, &wfd);
	if (hFindFile != INVALID_HANDLE_VALUE) 
	{
		do {
			fn.Format(L"%s", wfd.cFileName);
			FileName.push_back(fn);
		} while (FindNextFile(hFindFile, &wfd));
	}
}

void Plugin_Dll::LoadDll(int dwPid)
{
	typedef int (*FUN)(int dwPid);
	FUN g_pFun = nullptr;
	EnumFile();
	char* str;
	char* str_last;
	CString nPath;
	CString n;
	n.Format(L"\\");
	USES_CONVERSION;
	for (size_t i = 0; i < FileName.size(); i++)
	{
		str = W2A(FileName[i]);
		if (strcmp(str, ".") == 0 || strcmp(str, "..") == 0)
		{
			continue;
		}
		nPath.Format(L"%s", PATH + n + FileName[i]);
		str = W2A(nPath);
		str_last=FileNameLast(str);
		if (strcmp(str_last,"dll")==0)
		{
			//1. ����dll�ļ� �õ�ģ����
			HMODULE nhModule = LoadLibrary(nPath);
			//2. ����dll�еĺ���
			g_pFun = (FUN)GetProcAddress(nhModule, "Fun");
			//3. ������
			g_pFun(dwPid);
			//4. �ͷ�dll
			FreeLibrary(nhModule);

		}
	}
}

char* Plugin_Dll::FileNameLast(const char* path)
{
	char filenameLast[100] = { 0 };
	char* tmp = nullptr;
	tmp = (char*)strrchr(path, '.');
	if (tmp == NULL)
	{
		return 0;
	}
	strcpy_s(filenameLast, tmp + 1);//filenameLast���Ǻ�׺
	return filenameLast;
}
