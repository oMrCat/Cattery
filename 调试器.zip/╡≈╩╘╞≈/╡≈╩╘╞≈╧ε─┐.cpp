﻿#include<stdio.h>
#include"debugger.h"
#include"Plugin_Dll.h"
#include"Traversal_process.h"

int main()
{
	//Plugin_Dll nPlugin;
	debugger debug;
	Traversal_process Processid;
	int Pid = Processid.nProcess();
	int choice;
	printf("1.打开程序，2.附加程序");
	scanf_s("%d", &choice);
	if (choice == 1)
	{
		debug.open("111.exe");
		//nPlugin.LoadDll(debug.debugEvent.dwProcessId);
		debug.run();
	}
	else if (choice == 2)
	{
		if (debug.Open(Pid) != 0)
		{
			debug.run();
		}
		else
		{
			printf("调试器不能附加到活动程序");
		}
	}
	
	return 0;
}